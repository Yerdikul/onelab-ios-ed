//
//  ViewController.swift
//  one.lab.2.1
//
//  Created by Nurbolat Yerdikul on 02.03.2024.
//
// disable
import UIKit
import Alamofire


class ViewController: UIViewController {
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        print("String")
        // Do any additional setup after loading the view.
    }
}
