//
//  New2.swift
//  one.lab.2.1
//
//  Created by Nurbolat Yerdikul on 02.03.2024.
//

import Foundation
    