//
//  RealmStore.swift
//  one-lab-4.0
//
//  Created by Диас Сайынов on 26.03.2024.
//
import RealmSwift

final class RealmStore {
    private let delegate = UIApplication.shared.delegate as? AppDelegate
    private lazy var realm =  {
        delegate?.realm
    }()

    func save(user: User) {
        try! realm.write {
            realm.add(user)
        }
    }

    func fetchUser(name: String) -> User? {
        realm.objects(User.self).filter("name == %@", name).first
    }

    func fetchAllUsers() -> Results<User> {
        realm.objects(User.self)
    }
}
