//
//  User+CoreDataClass.swift
//  one-lab-4.0
//
//  Created by Nurbolat Yerdikul on 10.03.2024.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
