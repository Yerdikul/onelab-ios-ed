//
//  RealmStore.swift
//  one-lab-4.0
//
//  Created by Arman on 24.03.2024.
//

import UIKit
import RealmSwift

final class RealmStore {
    func performMigration(schemaVersion: UInt64) {
        let config = Realm.Configuration(
            schemaVersion: schemaVersion
        )
//        let config = Realm.Configuration(
//            schemaVersion: 1,
//            migrationBlock: { migration, oldSchemaVersion in
//                if oldSchemaVersion < 1 {
//                    // Define the migration to convert ObjectId to String
//                    migration.enumerateObjects(ofType: UserRealmObject.className()) { oldObject, newObject in
//                        guard let oldId = oldObject?["id"] as? ObjectId else { return }
//                        let newId = oldId.stringValue // Convert ObjectId to String
//                        newObject?["id"] = newId
//                    }
//                }
//            }
//        )
        Realm.Configuration.defaultConfiguration = config
    }
    
    func save(id: String, firstName: String, count: Int32) {
        let userRealmObject = UserRealmObject(value: [
            "id": id,
            "count": count,
            "firstName": firstName,
            "lastName": firstName
        ])
        do {
            let realm = try Realm()
            print("User Realm User file location: \(realm.configuration.fileURL!.path)")
            try realm.write {
                realm.add(userRealmObject)
            }
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func fetchAllUsers() -> [UserRealm]? {
        performMigration(schemaVersion: 1)
        do {
            let realm = try Realm()
            let results = realm.objects(UserRealmObject.self)
            return results.map { userRealmObject in
                return UserRealm(userRealmObject: userRealmObject)
            }
        } catch let error {
            print(error.localizedDescription)
        }
        return nil
    }
}
