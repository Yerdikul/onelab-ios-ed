//
//  UserRealmObject.swift
//  one-lab-4.0
//
//  Created by Arman on 24.03.2024.
//

import Foundation
import RealmSwift

class UserRealmObject: Object {
    @Persisted(primaryKey: true) var id: String
    @Persisted var count: Int32
    @Persisted var firstName: String?
    @Persisted var lastName: String?
}
