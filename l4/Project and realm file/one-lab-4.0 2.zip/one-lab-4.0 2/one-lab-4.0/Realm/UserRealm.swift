//
//  User.swift
//  one-lab-4.0
//
//  Created by Arman on 24.03.2024.
//

import Foundation

struct UserRealm: Identifiable { // Used to communicate with views
    public var id: String
    public var count: Int32
    public var firstName: String?
    public var lastName: String?
}

extension UserRealm {
    init(userRealmObject: UserRealmObject) {
        self.id = userRealmObject.id
        self.count = userRealmObject.count
        self.firstName = userRealmObject.firstName
        self.lastName = userRealmObject.lastName
    }
}
