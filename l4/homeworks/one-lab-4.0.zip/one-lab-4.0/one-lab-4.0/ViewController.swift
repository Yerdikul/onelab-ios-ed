//
//  ViewController.swift
//  one-lab-4.0
//
//  Created by NYerdikul on 10.03.2024.
//

import UIKit
import RealmSwift

class Parent {
    var child: Child?
    deinit {
        print("Parent deinitialized")
    }
}

class Child {
    var parent: Parent?
    deinit {
        print("Child deinitialized")
    }
}

class CustomUIAlertController: UIAlertController {
    override func loadView() {
        super.loadView()
        NotificationCenter.default.removeObserver(self)
    }
    
    deinit {
        print("deinit")
    }
}

class ViewController: UIViewController {

    let realm = try! Realm()

    @IBOutlet weak var tableView: UITableView!

    private var users: Results<UserRealm>!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUsers()

        users = realm.objects(UserRealm.self)
        // Do any additional setup after loading the view.
    }

    @IBAction func addButtonPressed(_ sender: Any) {
        let controller = CustomUIAlertController(title: "Name", message: nil, preferredStyle: .alert)
        controller.addTextField()

        let action = UIAlertAction(title: "Сохранить", style: .default) { _ in
            let text = controller.textFields?.first
            guard let newText = text?.text, !newText.isEmpty else { return }

            let user = UserRealm()
            user.fullName = newText

            try! self.realm.write({
                self.realm.add(user)
                self.tableView.reloadData()
            })
        }

        controller.addAction(action)
        present(controller, animated: true)


        doMemoryLeak()
    }
    
    func doMemoryLeak() {
        let parent = Parent()
        let child = Child()
        parent.child = child
        child.parent = parent
    }
}

// MARK: -  Table view data source

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "UserCell") as? UserTableViewCell else { return UITableViewCell() }
        let user = users?[indexPath.row]
        
//        cell.countLabel.text = "\(user?.count ?? 0)"
//        cell.nameTitle.text = user?.firstName ?? "" + " " + (user?.lastName ?? "")

        cell.nameTitle.text = user?.fullName

        return cell
    }
}


private extension ViewController {
    func updateUsers() {
//        users = CoreDataStore().fetchAllUsers()
    }
}
