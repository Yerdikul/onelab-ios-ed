//
//  User.swift
//  one-lab-4.0
//
//  Created by Maxim Tvilinev on 25.03.2024.
//

import Foundation
import RealmSwift

class UserRealm: Object {
    @objc dynamic var fullName = ""
}
