//
//  RealmDataStore.swift
//  one-lab-4.0
//
//  Created by Rustem Orazbayev on 3/25/24.
//

import Foundation
import RealmSwift

final class RealmDataStore {
    private lazy var realm: Realm = {
        do {
            return try Realm()
        } catch {
            fatalError("Failed to open Realm: \(error)")
        }
    }()
    
    func save(id: UUID, name: String, count: Int) {
        let user = RealmUser()
        user.id = id.uuidString
        user.firstName = name
        user.lastName = name
        user.count = count
        
        do {
            try realm.write {
                realm.add(user)
            }
        } catch {
            fatalError("Failed to save user: \(error)")
        }
    }
    
    func fetchUser(name: String) -> RealmUser? {
        return realm.objects(RealmUser.self).filter("firstName = %@", name).first
    }
    
    func fetchAllUsers() -> [RealmUser] {
        return Array(realm.objects(RealmUser.self))
    }
}

class RealmUser: Object {
    @objc dynamic var id: String = ""
    @objc dynamic var firstName: String = ""
    @objc dynamic var lastName: String = ""
    @objc dynamic var count: Int = 0

    override static func primaryKey() -> String? {
        return "id"
    }
}
